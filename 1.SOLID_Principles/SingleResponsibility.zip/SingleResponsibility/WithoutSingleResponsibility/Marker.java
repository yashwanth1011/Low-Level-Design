package WithoutSingleResponsibility;

public class Marker {
    String color;
    int cost;
    public Marker(String color, int cost){
        this.color = color;
        this.cost = cost;
    }
    
}
