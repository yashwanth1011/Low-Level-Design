## With Single Responsibility Principle VS Without Single Responsibility Principle

