import WithoutSingleResponsibility.Marker;
import WithoutSingleResponsibility.Invoice;

public class Main{
    public static void main(String[] args){
        Marker marker = new Marker("green", 90);
        Invoice invoice = new Invoice(marker, 4);

        System.out.println("Total Price is " + invoice.getTotal());  // Getting the Total

        invoice.saveToDb(); // Saving the file to DB functionality

        invoice.printInvoice();  // Printing Invoice
        

    }
}